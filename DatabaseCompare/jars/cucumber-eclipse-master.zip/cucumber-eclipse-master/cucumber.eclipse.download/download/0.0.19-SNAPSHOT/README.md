
# Download Cucumber-Eclipse-plugin
- This directory used to automatically publish cucumber-eclipse plugin as an archive(zip) by build process. 
- Plugin can be downloaded and installed from Eclipse offline.

## How to Download the latest Plugin
- Please download the plugin from below directory : 
```gherkin
 cucumber.eclipse.download\download\0.0.19-SNAPSHOT\cucumber-eclipse-plugin-0.0.19-SNAPSHOT.zip
```
