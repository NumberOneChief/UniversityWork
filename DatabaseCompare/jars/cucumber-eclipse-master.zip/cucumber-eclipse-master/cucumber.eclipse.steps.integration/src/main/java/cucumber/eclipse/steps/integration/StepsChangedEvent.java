package cucumber.eclipse.steps.integration;

public class StepsChangedEvent {
}
