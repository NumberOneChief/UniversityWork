package cucumber.eclipse.steps.integration;

public interface IStepListener {

    void onStepsChanged(StepsChangedEvent event);
}
